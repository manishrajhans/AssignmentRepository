﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3_Switch_Case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int number = Convert.ToInt32(Console.ReadLine());

            switch(number)
            {
                case 1:
                    Console.WriteLine("The number is 01");
                    break;
                case 2:
                    Console.WriteLine("The number is 02");
                    break;
                case 3:
                    Console.WriteLine("The number is 03");
                    break;
                case 4:
                    Console.WriteLine("The number is 04");
                    break;
                case 5:
                    Console.WriteLine("The number is 05");
                    break;
                default:
                    Console.WriteLine("Invalid number");
                    break;
            }
            Console.ReadKey();

        }
    }
}
