﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4_School_Data
{
    public class student
    {
        public int RollNo { get; set; }

        public string StudentName { get; set; }

        public float Age { get; set; }

        public string Gender { get; set; }

        public DateTime DOB { get; set; }

        public string Address { get; set; }

        public float Percentage { get; set; }

        public student()
        {
            RollNo = 0;
            StudentName = "";
            Age = 0.0f;
            DateTime DOB;
            Address = "";
            Percentage = 00.0f;
        }
        public virtual string GetData()
        {
            return $"RollNo:{RollNo},StudentName:{StudentName},Age:{Age},Gender:{Gender}, DOB:{DOB},Address:{Address},Percentage:{Percentage}";

        }
    }

}
