﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4_School_Data
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the records:");
            int size = Convert.ToInt32(Console.ReadLine());
            size = size + 1;
            var std = new student[size];
            Console.WriteLine("Employee records");
            Console.WriteLine("***********************************************************");
            for (int i = 1; i < size; i++)
            {
                std[i] = new student();
                Console.WriteLine("Enter Roll No:");
                int RollNo = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Student name:");
                string name = Console.ReadLine();

                Console.WriteLine("Enter Age:");
                float Age = Single.Parse(Console.ReadLine());

                Console.WriteLine("Enter Gender M/F:");
                string gender = Console.ReadLine();

                Console.WriteLine("Enter DOB(DD//MM/YYYY)");
                DateTime DOB = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter Address:");
                string Address = Console.ReadLine();

                Console.WriteLine("Enter Percentage:");
                float Percentage = Single.Parse(Console.ReadLine());

                Console.WriteLine("****************************************************");
                Console.WriteLine("Record-" + i + "");
                Console.WriteLine("RollNo:{0},StudentName:{1},Age:{2},Gender:{3},DOB:{4},Address:{5},Percentage:{6}",RollNo,name,Age,gender,DOB,Address,Percentage);
                Console.WriteLine("****************************************************");
                Console.ReadKey();

            }

        }
    }
}
