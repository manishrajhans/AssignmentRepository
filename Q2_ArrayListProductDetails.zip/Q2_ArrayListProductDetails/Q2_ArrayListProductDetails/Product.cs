﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2_ArrayListProductDetails
{
    class Product
    {
        public int ProductNo { get; set; }
        public string Name { get; set; }

        public double Rate { get; set; }

        public int Stock { get; set; }

        public Product(int pno, string name, double rate, int stock)
        {
            ProductNo = pno;
            Name = name;
            Rate = rate;
            Stock = stock;
            
        }
    }
}
