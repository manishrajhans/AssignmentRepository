﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Collections;


namespace Q2_ArrayListProductDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            int flag = 0;


            

            WriteLine("~ARRAY LIST~\n1. Add\n2. Display\n3. Delete\n4. Search\n5. Exit");

            while(true)
            {
                WriteLine("\nEnter your choice?");
                int choice = int.Parse(ReadLine());
                switch (choice)
                {
                    case 1:
                        //Add
                        Write("Enter the details =>\nProduct No : ");
                        int pno = int.Parse(ReadLine());
                        Write("Name: ");
                        string name = ReadLine();
                        Write("Rate : ");
                        double rate = double.Parse(ReadLine());
                        Write("Quantity : ");
                        int qty = int.Parse(ReadLine());

                        Product p = new Product(pno, name, rate, qty);
                        al.Add(p);

                        break;

                    case 2: //display

                        foreach (Product obj1 in al)
                        {
                            if (obj1 != null)
                            {
                                WriteLine("____________________________________________________________________");
                                WriteLine($"Product No : {obj1.ProductNo}, Product Name : {obj1.Name}, Rate : {obj1.Rate}, Qty : {obj1.Stock}");
                                WriteLine("_______________________________________________________________________");
                            }
                        }
                        break;

                    case 3://delete
                        Write("Enter Id of product to delete : ");
                        int del_id = int.Parse(ReadLine());

                       
                        Product obj = null;
                        for (int i = 0; i < al.Count; i++)
                        {
                            if ((al[i] as Product).ProductNo == del_id)
                            {
                                obj = al[i] as Product;
                                break;
                            }
                        }

                        if (obj != null)
                        {
                            
                            al.Remove(obj);
                            WriteLine("Deleted!");

                        }
                        break;

                    case 4: //Search
                        Write("Enter ProductNo of product to search : ");
                        int id = int.Parse(ReadLine());
                        int f = 0;

                        foreach (Product obj2 in al)
                        {
                            if (obj2.ProductNo == id) 
                            {
                                WriteLine("____________________________________________________________________");
                                WriteLine($"Product No : {obj2.ProductNo}, Product Name : {obj2.Name}, Rate : {obj2.Rate}, Qty : {obj2.Stock}");
                                WriteLine("_______________________________________________________________________");
                                f = 1;
                            }
                              
                               
                           
                        }
                        if (f == 0)
                            WriteLine("Product not found!");
                        break;

                    case 5:flag = 1;
                        break;

                    default: WriteLine("Invalid Input");
                        break;
                }
                if (flag == 1)
                    break;
            }
        
            

            

           

            

            ReadKey();


        }
    }
}
