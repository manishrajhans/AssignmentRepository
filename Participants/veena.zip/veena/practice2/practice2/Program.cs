﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("enter a number");
            //int num = Convert.ToInt32(Console.ReadLine());
            //for(int i=1;i<=10;i++)
            //{
            //    Console.WriteLine($"{num} * {i} =  {num * i}");
            //}

            //Console.ReadLine();



            //Console.WriteLine("enter 3 numbers");
            // int x = Convert.ToInt32(Console.ReadLine());
            // int y = Convert.ToInt32(Console.ReadLine());
            // int z = Convert.ToInt32(Console.ReadLine());

            // Console.WriteLine($"{x + y * z}   ,  {x * y +y * z}");
            // Console.ReadLine();

            //Console.WriteLine("Enter a String");
            //string name = Console.ReadLine();
            //int n = name.Length;
            //Console.Write(name[n-1]);
            //string x = name.Substring(1,n-2);
            //Console.Write(x);
            //Console.WriteLine(name[0]);

            Console.WriteLine("enter a string");
            string str = Console.ReadLine();
            string[] word = str.Split(' ');
            int x = word[0].Length;
            String news = string.Empty;
            foreach (string item in word)
            {
                if(item.Length>x)
                {
                     news = item;
                }
            }
            Console.WriteLine(news); 
            
            
            
            Console.ReadLine();




        }
    }
}
