﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace practice13
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            string name = "input.txt";
            List<string> str = new List<string>();
            try
            {
                using (FileStream fs = File.OpenRead(name))
                {
                    using (StreamReader sw = new StreamReader(fs))
                    {
                       
                        string input;
                        while ((input = sw.ReadLine()) != null)
                        {
                            str.Add(input);
                            //count++;
                        }
                    }
                }
                //Console.WriteLine("Enter the line wanted");
                //int line = int.Parse(Console.ReadLine());
                //int x = line - 1;
                //Console.WriteLine(str[x]);
                // Console.WriteLine(str[str.Count-1]);
                Console.WriteLine($"no of lines in file {str.Count}");

              //  Console.WriteLine("enter the line no from where to start ");
              //  int line = int.Parse(Console.ReadLine());
              //while(line<str.Count)
              
              //  {
              //      Console.WriteLine(str[line]);
              //     line++;
              //  }
                

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();

        }
    }
}