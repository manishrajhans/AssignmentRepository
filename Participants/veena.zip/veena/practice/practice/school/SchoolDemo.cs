﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.school
{
    class SchoolDemo
    {
        private int rollno;
        private string name;
        private byte age;

        public int Rollno { get; set; }
        public string Name { get; set; }
        public byte Age { get; set; }

        public SchoolDemo()
        {
            Rollno = 0;
            Name = string.Empty;
            Age = 0;
        }
        public SchoolDemo(int no,string nm,byte ag)
        {
            this.Rollno = no;
            this.Name = nm;
            this.Age = ag;
        }

        //public void Display()
        //{
        //    Console.WriteLine(this.Rollno);
        //    Console.WriteLine(this.Name);
        //    Console.WriteLine(this.Age);
        //}
    }
}
