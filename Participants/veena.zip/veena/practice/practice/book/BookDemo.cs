﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.book
{
    class BookDemo
    {
        string[,] bk = new string[2, 4];
        public void Accept()
        {
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    bk[i, j] = Console.ReadLine();
                }
            }
        }
        public void Display()
        {
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(bk[i,j]);
                }
                Console.WriteLine();
            }
        }
    }
}
