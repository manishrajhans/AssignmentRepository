﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.arith
{
    class Arithmetic
    {
        

        public void Add(int n1, double n2) => Console.WriteLine(n1 + n2);
        public void Sub(int n1, double n2) => Console.WriteLine(n1 - n2);
        public void Mul(int n1, double n2) => Console.WriteLine(n1 * n2);
        public void Div(int n1, double n2) => Console.WriteLine(n1 / n2);
    }
}
