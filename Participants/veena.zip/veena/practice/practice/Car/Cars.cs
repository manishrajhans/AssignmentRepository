﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.Car
{
    class Cars
    {
        private int carid;
        private int model;
        private int year;
        private int price;
        public int Carid { get; set; }
        public int Model { get; set; }
        public int Year { get; set; }
        public int Price { get; set; }

        public void Add(int id,int mo,int yr,int pr)
        {
            this.Carid = id;
            this.Model = mo;
            this.Year = yr;
            this.Price = pr;
        }
       public void Display()
        {
            Console.WriteLine($"{this.Carid}   {this.Model}  {this.Year}   {this.Price} ");
        }

    }
}
