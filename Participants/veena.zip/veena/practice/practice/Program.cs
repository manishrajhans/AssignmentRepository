﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using practice.emp;
using practice.arith;
using practice.school;
using practice.product;
using practice.book;
using practice.Participants;
using practice.Birdfly;
using practice.Car;

namespace practice
{
    class Program
    {

        struct Number
        {
            private int n;
            public void set(int num)
            {
                n = num;
            }
            public void Square()
            {
                Console.WriteLine(n * n);
            }
            public void Cube()
            {
                Console.WriteLine(n * n*n);
            }
        }





        static void Main(string[] args)
        {

            //Employee[] e = new Employee[3];
            //int i = 0;
            //while ( i < 3)
            //{
            //    Console.WriteLine("enter id and name");
            //    int id = Convert.ToInt32(Console.ReadLine());
            //    string s = Console.ReadLine();
            //    e[i] = new Employee(id, s);
            //    i++;
            //}
            //int k = 0;
            //while(k < 3)
            //{
            //    e[k].display();
            //    k++;
            //}

            //Console.WriteLine("entr num1");
            //int nu1 = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("entr num2");
            //double nu2 = Convert.ToInt32(Console.ReadLine();

            //Arithmetic a = new Arithmetic();
            //a.Add(nu1, nu2);
            //a.Sub(nu1, nu2);
            //a.Mul(nu1, nu2);
            //a.Div(nu1, nu2);

            //Console.WriteLine("enter number");
            //int n = Convert.ToInt32(Console.ReadLine());

            //switch(n)
            //{
            //    case 1:
            //        Console.WriteLine("num is 1");
            //        break;
            //    case 2:
            //        Console.WriteLine("num is 2");
            //        break;
            //    case 3:
            //        Console.WriteLine("num is 3");
            //        break;
            //    case 4:
            //        Console.WriteLine("num is 4");
            //        break;
            //    case 5:
            //        Console.WriteLine("num is 5");
            //        break;
            //    default:
            //        Console.WriteLine("out of set");
            //        break;
            //}

            //SchoolDemo sd = new SchoolDemo(1, "veena", 21);
            ////sd.Display();
            //Console.WriteLine(sd.Rollno);


            //Number nu = new Number();
            //Console.WriteLine("entr num");
            //int v = Convert.ToInt32(Console.ReadLine());
            //nu.set(v);

            //Console.WriteLine("entr a value");
            //int op = Convert.ToInt32(Console.ReadLine());

            //switch(op)
            //{
            //    case 1:
            //        nu.Square();
            //        break;
            //    case 2:
            //        nu.Cube();
            //        break;
            //    default:
            //        Console.WriteLine("wrong input");
            //        break;
            //}


            //int[,] arr = new int[2, 3];


            //for(int i=0;i<2;i++)
            //{
            //    for(int j=0;j<3;j++)
            //    {
            //       arr[i,j]= Convert.ToInt32(Console.ReadLine());

            //    }
            //}
            //for (int i = 0; i < 2; i++)
            //{
            //    for (int j = 0; j < 3; j++)
            //    {
            //        Console.Write(arr[i, j]);
            //    }
            //    Console.WriteLine();
            //}

            //ProductDemo pd = new ProductDemo(1, "veena", 3, 6);
            //pd.Display();
            //pd.Q();

            //BookDemo bd = new BookDemo();
            //bd.Accept();
            //bd.Display();

            //Console.WriteLine("marks");
            //int f = Convert.ToInt32(Console.ReadLine());
            //int w = Convert.ToInt32(Console.ReadLine());
            //int d = Convert.ToInt32(Console.ReadLine());

            //Participant p = new Participant(f, w, d);
            //p.tot();
            //p.per();


            //Bird b = new Bird("Eagle", double.Parse("200"));
            //b.fly();
            //b.fly(int.Parse("300"));

            int i = 0;
            Cars c = new Cars();
            c[] ob = new c[i];
            while (true)
            {
                Console.WriteLine("Enter choice");
                Console.WriteLine("1.Add 2.Display 3.Search 4.Delete 5.Modify");
                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("enter the car id");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter the car model");
                        int mo = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter the car year");
                        int yr = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("enter the car price");
                        int pr = Convert.ToInt32(Console.ReadLine());
                        ob[i++].Add(id, mo, yr, pr);
                        
                        break;
                    case 2:
                        for (int j = 0; j < ob.Length; j++)
                        {
                            ob[j].Display();
                        }
                        break;
                }
            }
            Console.ReadKey();
        }
    }
}
