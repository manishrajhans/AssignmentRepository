﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.emp
{
    class Employee
    {
        private int empid;
        private string ename;
        //private string city;
        //private string add;
        //private int sal;

        public int Id { get; set; }

        public string Name { get; set; }
        public Employee()
        {
            empid = 0;
            ename = string.Empty;
        }

        public Employee(int id,string nm)
        {
            this.empid = id;
            this.ename = nm;
        }
        public void display()
        {
            Console.Write(this.empid);
            Console.WriteLine(this.ename);
            
;        }
    }
}
