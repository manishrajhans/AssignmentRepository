﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.product
{
    class ProductDemo
    {
       public int id;
       public string name;
       public int qty;
       public int price;
        public ProductDemo(int id,string name,int qty,int price)
        {
            this.id = id;
            this.name = name;
            this.qty = qty;
            this.price = price;
        }
        public void Display()
        {
            object i = this.id;
            object n = this.name;
            object q = this.qty;
            object p = this.price;

            Console.WriteLine($"{i}     {n}    {q}    {p}    ");

            id = Convert.ToInt32(i);
            name = Convert.ToString(n);
            qty= Convert.ToInt32(q);
            price= Convert.ToInt32(p);

            Console.WriteLine($"{id}     {name}    {qty}    {price}    ");
        }
        public void Q()
        {
            Console.WriteLine(this.qty * this.price);
        }
    }
}
