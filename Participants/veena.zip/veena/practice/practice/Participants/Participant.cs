﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice.Participants
{
    class Participant
    {
        private string name;
        private int FoundationMarks;
        private int WebBasicMarks;
        private int DotNetMarks;
        private int TotMarks;
        private int ObtainedMarks;
        private int Percentage;

        public int fmarks 
        {
            get
            {
                return FoundationMarks;
            }
            set
            {
                if(FoundationMarks>0 && FoundationMarks<100)
                {
                    FoundationMarks = value;
                }
                else
                {
                    throw new Exception();
                }
                
            }
            
        }

        public Participant()
        {
            TotMarks = 300;
            
        }
        public Participant(int fm,int wm,int dm)
        {
            this.FoundationMarks = fm;
            this.WebBasicMarks = wm;
            this.DotNetMarks = dm;
        }
        public void tot()
        {
            this.ObtainedMarks = this.FoundationMarks + this.WebBasicMarks + this.DotNetMarks;
            Console.WriteLine(ObtainedMarks);
        }
        public void per()
        {
            this.Percentage = (this.ObtainedMarks*100)/300;
            Console.WriteLine(this.Percentage);
        }
        static Participant()
        {
            string cnm = "cu";
        }
    }
}
