﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice5
{
    class Program
    {
        static void fib(int s)
        {
            int num1 = 0;
            int num2 = 1;
            Console.WriteLine(num1);
            Console.WriteLine(num2);
            for (int i = 3; i <= s; i++)
            {
                int num3 = num1 + num2;
                Console.WriteLine(num3);
                num1 = num2;
                num2 = num3;

            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number of fib series wanted");
            int s = int.Parse(Console.ReadLine());
            if(s==0)
            {
                Console.WriteLine(s);
            }
            else if(s==1)
            {

                Console.WriteLine("0 and 1");
            }
            else
            {
                fib(s);
            }
            
            Console.ReadLine();
        }
    }
}
