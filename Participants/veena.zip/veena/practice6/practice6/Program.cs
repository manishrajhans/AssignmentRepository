﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace practice6
{
    class Program
    {
        static void Main(string[] args)
        {
            //using (FileStream fs = new FileStream("blank.txt", FileMode.Create , FileAccess.Write))
            //{

            //   Console.WriteLine("file created");

            //}

            //File.Delete("blank.txt");
            //Console.WriteLine("deleted");

            string name = "n.txt";
            try
            {
                if (File.Exists(name))
                {
                    File.Delete(name);
                }
                using (FileStream fs = new FileStream(name, FileMode.Create, FileAccess.Write))
                {
                    Console.WriteLine("file created");
                }
                using (StreamWriter sw = new StreamWriter(name))
                {
                    sw.WriteLine("c# programming");
                    Console.WriteLine("text inserted");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
             
               try
                {
                    using (FileStream f = new FileStream(name, FileMode.Open, FileAccess.Read))
                    {
                        using (StreamReader sw = new StreamReader(name))
                        {
                            string input;
                            while ((input = sw.ReadLine()) != null)
                            {
                                Console.WriteLine(input);
                            }

                        }
                    }
                }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();



        }
        }
    }

