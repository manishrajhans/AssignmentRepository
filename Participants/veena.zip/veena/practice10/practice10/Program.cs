﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace practice10
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = { "c#", "program", "array" };

            string name = "array.txt";
            try
            {
                if (File.Exists(name))
                {
                    File.Delete(name);
                }
                using (FileStream fs = new FileStream(name, FileMode.Create, FileAccess.Write))
                {
                    Console.WriteLine("file created");
                }
                using (StreamWriter sw = new StreamWriter(name))
                {
                    for (int i = 0; i < arr.Length; i++)
                    { 
                        if(!arr[i].Contains("array"))
                            sw.WriteLine(arr[i]);
                    }

                    Console.WriteLine("text inserted");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                using (FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read))
                {
                    using(StreamReader s= new StreamReader(name))
                    {
                        string input;
                        while ((input = s.ReadLine()) != null)
                        {
                            Console.WriteLine(input);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



            Console.ReadKey();
        }
    }
}
