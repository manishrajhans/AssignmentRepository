﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace practice12
{
    class Program
    {
        static void Main(string[] args)
        {
            string name2 = "copy2.txt";
            string name = "copy1.txt";
            try
            {
                if (File.Exists(name))
                {
                    File.Delete(name);
                }
                using (FileStream fs = File.Create(name))
                {
                    Console.WriteLine("file created");
                } 
                    using (StreamWriter sw = File.AppendText(name))
                    {

                        sw.WriteLine("contents of file");
                        Console.WriteLine("text inserted");
                    }

                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                File.Copy(name, name2);
                {
                    using (FileStream f = File.OpenRead(name2))
                    {
                        using (StreamReader sw = new StreamReader(name2))
                        {
                            string input;
                            while ((input = sw.ReadLine()) != null)
                            {
                                Console.WriteLine(input);
                            }

                        }
                    }
                   
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
