﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace practice11
{
    class Program
    {
        static void Main(string[] args)
        { 
            string name = "array.txt";
            try
            {
 
                using (FileStream fs = new FileStream(name, FileMode.Append, FileAccess.Write))
                {
                    Console.WriteLine("file created");
                }
                using (StreamWriter sw = File.AppendText(name))
                {
                    
                            sw.WriteLine("append");
                  

                    Console.WriteLine("text inserted");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                using (FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read))
                {
                    using (StreamReader s = new StreamReader(name))
                    {
                        string input;
                        while ((input = s.ReadLine()) != null)
                        {
                            Console.WriteLine(input);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
