﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a1 = new int[] { 1, 2, 3, 4, 5 };
            int[] a2 = new int[] { 6, 7, 8, 9, 10 };
            int[] a3 = new int[5];
            for (int i = 0; i < 5; i++)
            {
                a3[i] = a1[i] * a2[i];
                Console.WriteLine(a3[i]);
            }
            
            Console.ReadLine();
        }
    }
}
