﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CS_DemoParameterEnhancementINCS7
{
    class Program
    {
        static void Main(string[] args)
        {
            Write("enter a number: ");
            string input = ReadLine();
            //int i;
            //if (int.TryParse(input,out int i)) //C# 7.0 enhancement for out paramter (local declaration)
            if (int.TryParse(input, out int _)) //C# 7.0 enhancement for out paramter (local declaration)
            {
                //WriteLine($"square of {i} is { i * i }");
                WriteLine($"it's a number");

            }
            else
            {
                WriteLine("NaN");
            }
            ReadKey();
        }
    }
}
