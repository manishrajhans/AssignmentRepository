﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Assignment_Q1_Task1
{
    public class Employee1
    {
        // ===============Task 1==================
        public int _EmpId;
        public string _EmpName;
        public string _EmpAddress;
        public string _EmpCity;
        public string _EmpDept;
        public int _EmpSalary;

        public void setvalues(int EmpId, string EmpName, string EmpAddress, string EmpCity, string EmpDept, int EmpSalary)
        {
            _EmpId = EmpId;
            _EmpName = EmpName;
            _EmpName = EmpAddress;
            _EmpCity = EmpCity;
            _EmpDept = EmpDept;
            _EmpSalary = EmpSalary;
        }

        public int getsalary()
        {
            return _EmpSalary;
        }
    }
}

