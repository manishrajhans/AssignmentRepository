﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1_Assignment_Q1_Task1;

namespace Q1_Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee1 emp1 = new Employee1();
            emp1.setvalues(101, "Jerry", "Aland road", "Gulbarga", "IT", 20000);
            Console.WriteLine($"Salary : {emp1.getsalary()}");
            Console.ReadLine();
        }
    }
}
