﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{ 
    public class Student
    {
        public int rollNumber;
        public string studentName;
        public byte age;
        public char gender;
        public DateTime dateOfBirth;
        public string address;
        public float percentage;

        public Student()
        {
            rollNumber = 0;
            studentName = " ";
            age = 0;
            gender = ' ';
            dateOfBirth = DateTime.Now;
            address = " ";
            percentage = 0.0f;
        }
    }
}
