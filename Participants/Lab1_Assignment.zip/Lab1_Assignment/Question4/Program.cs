﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            s.rollNumber = 30;
            s.studentName = "Harry";
            s.age = 23;
            s.gender = 'F';
            s.dateOfBirth = new DateTime(2015, 11, 10, 8, 40, 30);
            s.address = "Aland road, Gulbarga";
            s.percentage = 66.3f;

            Console.WriteLine($"RollNumber : {s.rollNumber}, StudentName : {s.studentName}, Age : {s.age}, Gender : {s.gender}, DOB : {s.dateOfBirth}, Address : {s.address}, Percentage : {s.percentage}");
            Console.ReadKey();
        }
    }
}
