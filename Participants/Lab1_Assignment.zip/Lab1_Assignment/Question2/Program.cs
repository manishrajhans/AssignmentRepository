﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Question2;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            var flag = 1;
            while (flag > 0)
            {
                Console.WriteLine("Enter your choice: \n1.Add\n2.Subtract\n3.Multiply\n4.Divide\n5.Modulus\n6.Exit");
                var choice = int.Parse(Console.ReadLine());
                ArithmeticOperations obj = new ArithmeticOperations();
                double a = 0;
                double b = 0;
                if (choice != 6)
                {

                    Console.Write("Enter the two numbers (space separeted):");
                    string inp = Console.ReadLine(); // "1 2"
                    string[] values = inp.Split(' ');
                    a = double.Parse(values[0]);
                    b = double.Parse(values[1]);
                }
                // var b = double.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 6:
                        flag = 0;
                        break;

                    case 1:
                        Console.WriteLine(obj.Add(a, b));
                        break;

                    case 2:
                        Console.WriteLine(obj.Subtract(a, b));
                        break;

                    case 3:
                        Console.WriteLine(obj.Multiply(a, b));
                        break;

                    case 4:
                        Console.WriteLine(obj.Divide(a, b));
                        break;

                    case 5:
                        Console.WriteLine(obj.Modulus(a, b));
                        break;

                    default:
                        Console.WriteLine("Invalid Choice!!");
                        break;
                }
            }
        }
    }
}