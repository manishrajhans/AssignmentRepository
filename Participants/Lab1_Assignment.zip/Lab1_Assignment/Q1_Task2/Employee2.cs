﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_Task2
{
    class Employee2
    {
     // ===============Task 4==================
     
        private int _EmpId;

        public int EmpId
        {
            get
            {
                return _EmpId;
            }
            set
            {
                if (value > 0)
                {
                    _EmpId = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }

        private string _EmpName;

        public string EmpName
        {
            get
            {
                return _EmpName;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _EmpName = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }

        private string _EmpAddress;

        public string EmpAddress
        {
            get
            {
                return _EmpAddress;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _EmpAddress = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }

        private string _EmpCity;

        public string EmpCity
        {
            get
            {
                return _EmpCity;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _EmpCity = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }

        private string _EmpDept;

        public string EmpDept
        {
            get
            {
                return _EmpDept;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _EmpDept = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }

        private int _EmpSalary;

        public int EmpSalary
        {
            get
            {
                return _EmpSalary;
            }
            set
            {
                if (value > 0)
                {
                    _EmpSalary = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid");
                }
            }
        }
    }
}