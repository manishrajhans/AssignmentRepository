﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1_Task2;

namespace Lab1_Assignment_Q1_Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            // ===============Task 2 & 3==================
            var emp = new Employee2[10];

            for (int i = 0; i <= emp.Length - 1; i++)
            {
                emp[i] = new Employee2();
                Console.WriteLine("Enter Employee Id:");
                emp[i].EmpId = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Name:");
                emp[i].EmpName = Console.ReadLine();
                Console.WriteLine("Enter Employee Address:");
                emp[i].EmpAddress = Console.ReadLine();
                Console.WriteLine("Enter Employee City:");
                emp[i].EmpCity = Console.ReadLine();
                Console.WriteLine("Enter Employee Dept:");
                emp[i].EmpDept = Console.ReadLine();
                Console.WriteLine("Enter Employee Salray:");
                emp[i].EmpSalary = int.Parse(Console.ReadLine());

            }

            for (int i = 0; i <= emp.Length - 1; i++)
            {
                Console.WriteLine("The Employee Id is:" + emp[i].EmpId);
                Console.WriteLine("The Employee Name is:" + emp[i].EmpName);
                Console.WriteLine("The Employee Address is:" + emp[i].EmpAddress);
                Console.WriteLine("The Employee City is:" + emp[i].EmpCity);
                Console.WriteLine("The Employee Dept is:" + emp[i].EmpDept);
                Console.WriteLine("The Employee Salary is:" + emp[i].EmpSalary);
                Console.WriteLine();
            }

            Console.ReadKey();

        }
    }
}
