﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CS_Lab1.Lab1_Q1
{
    class Employee
    {
        private int EmployeeId;
        //lab1-Q1-Task-4
        public int _eId { get; set; }

        private string EmployeeName;
        public int _eName { get; set; }

        private string Address;
        public string _address { get; set; }
        private string City;
        public string _city { get; set; }
        private string Dept;
        public string _dept { get; set; }
        private double Salary;
        public double _salary { get; set; }
        public Employee()
        {

        }
        public Employee(int id, string name, string address, string city, string dept, double salary)
        {
            this.EmployeeId = id;
            this.EmployeeName = name;
            this.Address = address;
            this.City = city;
            this.Dept = dept;
            this.Salary = salary;
        }
        public void GetEmployeeData()
        {
            Console.WriteLine("Enter name");
            EmployeeName = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter salary");
            Salary = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayEmployee()
        {
            Console.WriteLine("Ename is " + EmployeeName);
            Console.WriteLine("Salary is " + Salary);
        }

    }
}
