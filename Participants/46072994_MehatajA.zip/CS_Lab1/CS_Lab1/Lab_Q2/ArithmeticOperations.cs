﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Lab1.Lab_Q2
{
    class ArithmeticOperations
    {
        public int num1;
        public double num2;

        public static double Add(int num1, double num2)
        {
            return num1 + num2;
        }
        public static double Subtract(int num1, double num2)
        {
            return num1 - num2;
        }
        public static double Multiply(int num1, double num2)
        {
            return num1 * num2;
        }
        public static double Divide(int num1, double num2)
        {
            return num1 / num2;
        }
        public static double Modulus(int num1, double num2)
        {
            return num1 % num2;
        }
    }
}
