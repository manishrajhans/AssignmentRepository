﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Lab1.Lab1_Q3
{
    class SchoolDemo
    {
        public int _rollNo;
        public string _studentName;
        public byte _age;
        public char _gender;
        public DateTime _dateOfBirth;
        public string _address;
        public float _percentage;

        public SchoolDemo()
        {

        }
    }
}
