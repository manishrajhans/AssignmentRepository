﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_Lab1.Lab1_Q1;
using CS_Lab1.Lab_Q2;
using CS_Lab1.Lab1_Q3;

namespace CS_Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            ////lab_1-q1-task-1
            ////employee e1 = new employee(101, "mehataj", "102 abc", "cta", ".net", 25000.0f);
            ////console.writeline($"employeeid :{e1._eid},employeename : {e1._ename},address : {e1._address},city : {e1._city},dept : {e1._dept},salary : {e1._salary}");


            //Lab_1-Q1-Task-2

            //Console.WriteLine("Enter Id: ");
            //int _eId = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter Name: ");
            //String _eName = Console.ReadLine();
            //Console.WriteLine("Enter Address: ");
            //String _address = Console.ReadLine();
            //Console.WriteLine("Enter city : ");
            //string _city = Console.ReadLine();
            //Console.WriteLine("Enter Department : ");
            //string _dept = Console.ReadLine();
            //Console.WriteLine("Enter Salary : ");
            //double _salary = int.Parse(Console.ReadLine());

            //Lab1-Q1-Task-3

            //Employee[] e = new Employee[10];
            //for(int i=1;i<=10;i++)
            //{
            //    Console.WriteLine($"Enter the data of employee with id : 10{i}");
            //    e[i] = new Employee();
            //    e[i].GetEmployeeData();
            //}

            //Console.WriteLine("Data of employees");
            //for(int i=1;i<=10;i++)
            //{
            //    e[i].DisplayEmployee();
            //}

            //Lab1-Q2
            //Console.WriteLine("Enter one Integer and One double :");
            //string s1 = Console.ReadLine();
            //string s2 = Console.ReadLine();

            //int n1 = Convert.ToInt32(s1);
            //double n2 = Convert.ToDouble(s2);

            //Console.WriteLine("Addition :" + ArithmeticOperations.Add(n1, n2));
            //Console.WriteLine("Subtraction :" + ArithmeticOperations.Subtract(n1, n2));
            //Console.WriteLine("Multipication :" + ArithmeticOperations.Multiply(n1, n2));
            //Console.WriteLine("Divison :" + ArithmeticOperations.Divide(n1, n2));
            //Console.WriteLine("Modulus :" + ArithmeticOperations.Modulus(n1, n2));

            //Lab1-Q3
            //Console.WriteLine("Enter a Number:");//LabManual 1-Q3
            //string n;
            //n = Console.ReadLine();
            //int num = Convert.ToInt32(n);
            //switch (num)
            //{
            //    case 1:
            //        Console.WriteLine("Valid");
            //        break;
            //    case 2:
            //        Console.WriteLine("Valid");
            //        break;
            //    case 3:
            //        Console.WriteLine("Valid");
            //        break;
            //    case 4:
            //        Console.WriteLine("Valid");
            //        break;
            //    case 5:
            //        Console.WriteLine("Valid");
            //        break;
            //    default:
            //        Console.WriteLine("Not Valid");
            //        break;
            //}

            //Lab1-Q4
            SchoolDemo s1 = new SchoolDemo()
            {
                _rollNo = 10,
                _studentName = "Guddu",
                _age = 20,
                _gender = 'F',
                _dateOfBirth = new DateTime(2005, 11, 10, 8, 40, 30),
                _address = "Bangalore",
                _percentage = 20.0f
            };
            Console.WriteLine($"Roll N0: {s1._rollNo},studentName: {s1._studentName},Age: {s1._age},Gender: {s1._gender}");
            Console.WriteLine($"DOB: {s1._dateOfBirth},Address:{s1._address},Percentage: {s1._percentage}");

            Console.ReadKey();
        }
    }
}
