﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Ques5.Books
{
    public class BooksDemo
    {
        public string[] BookInfo = { "BookName", "Author", "Publisher", "Price" };
        public string[,] Details = new string[2, 4];

        public void setDetails(int SrNo, string BookTitle, string BookAuthor, string BookPublisher, string BookPrice)
        {
            this.Details[SrNo, 0] = BookTitle;
            this.Details[SrNo, 1] = BookAuthor;
            this.Details[SrNo, 2] = BookPublisher;
            this.Details[SrNo, 3] = BookPrice;
        }
        public void DisplayInfo()
        {
            WriteLine();
            WriteLine("------------------------Book Details-------------------------------------");
            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    //WriteLine($"{BookInfo}:{this.Details[i, j]}");
                    
                    WriteLine($"{BookInfo[j]}  :  {this.Details[i, j]}" );

                }
            }
        }

    }
}
