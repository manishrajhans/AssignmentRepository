﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ques5.Books;
using static System.Console;

namespace Ques5
{
    class Program
    {
        static void Main(string[] args)
        {
            BooksDemo b = new BooksDemo();
            for (int i = 0; i < 1; i++)
            {
                Write("Enter Book Title : ");
                string book = ReadLine();

                Write("Enter Author Name : ");
                string author = ReadLine();

                Write("Enter Publisher Name : ");
                string publisher = ReadLine();

                Write("Enter Book Price : ");
                string price = ReadLine();

                b.setDetails(i, book, author, publisher, price);


            }
            b.DisplayInfo();
            
            ReadKey();
        }
    }
}
