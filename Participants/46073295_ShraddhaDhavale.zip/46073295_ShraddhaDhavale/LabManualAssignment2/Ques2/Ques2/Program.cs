﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ques2
{
    class Program
    {
        static void Main(string[] args)
        {
			int[,] matrix1 = new int[5, 6];

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 6; j++)
				{
					Console.WriteLine("Enter numbers : ");
					matrix1[i, j] = int.Parse(Console.ReadLine());
				}
			}

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < 6; j++)
				{
					//Console.WriteLine("Element({0},{1})={2}", i, j, matrix1[i, j]);
					Console.Write(matrix1[i, j] + " ");
				}
				Console.WriteLine(" ");
			}

			Console.ReadKey();
		}
    }
}
