﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Ques3
{
    class Program
    {
        static void Main(string[] args)
        {
            Write(" How many cities you want to input?  :  ");
            int number = Convert.ToInt32(Console.ReadLine());
            string[] val = new string[number];
            
            for (int i = 0; i < number; i++)
            {
                Write($"Enter City Name : ");
                val[i] = ReadLine();
            }

            WriteLine();
            WriteLine("The City Names you entered are : ");
            foreach (var city in val)
                WriteLine(city);

            ReadKey();
        }
    }
}
