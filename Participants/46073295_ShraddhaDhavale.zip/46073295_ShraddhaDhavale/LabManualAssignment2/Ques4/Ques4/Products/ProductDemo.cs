﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Ques4.Products
{
    public class ProductDemo
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public float Price { get; set; }
        public int Quantity { get; set; }
        public double AmountPayable { get; set; }

        public void GetData()
        {
            Write("Enter Product ID : ");
            ProductId = Convert.ToInt32(ReadLine());
            object o1 = ProductId; //boxing
            ProductId = (int)o1;  //unboxing

            Write("Enter Product Name : ");
            ProductName = ReadLine();
            object o2 = ProductName; //boxing
            ProductName = (string)o2;  //unboxing

            Write("Enter Quantity of Product : ");
            Quantity = Convert.ToInt32(ReadLine());

            Write("Enter Price : ");
            Price = Convert.ToInt32(ReadLine());
        }
        public void DisplayInfo()
        {
            WriteLine();
            WriteLine("-----------------Product Details ---------------");
            WriteLine($"Product ID : {ProductId}");
            WriteLine($"Product Name: {ProductName}");
            WriteLine($"Quantity of Product : {Quantity}");
            WriteLine($"Price of Product : {Price}");
        }
        public void CalculateAmount()
        {
            AmountPayable = Price * Quantity;
            WriteLine($"Amount Payable for the Product :{AmountPayable}");

        }
    }
}

