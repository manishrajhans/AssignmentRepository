﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ques4.Products;
using static System.Console;

namespace Ques4
{
    class Program
    {
        public static void Main(string[] args)
        {
            ProductDemo product = new ProductDemo();

            product.GetData();
            product.DisplayInfo();
            product.CalculateAmount();

            ReadKey();

        }
    }
}
