﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Ques1
{
    public struct DoCalc
    {
        private int Num1;

        public int Number1 //property
        {
            get { return this.Num1; }
            set { this.Num1 = value; }
        }
        public DoCalc(int No1) //constructor
        {
            this.Num1 = No1;

        }
        public void Sqr()
        {
            int sqr = Num1 * Num1;
            WriteLine($"Square of {Num1} is {sqr}");
        }
        public void Cube()
        {
            int cube = Num1 * Num1 * Num1;
            WriteLine($"Cube of {Num1} is {cube}");

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Write("Enter 1 for Square / 2 for Cube : ");
            int opr = int.Parse(ReadLine());

            Write("Enter your number : ");
            int number = int.Parse(ReadLine());
            DoCalc result = new DoCalc(number);
           
            switch (opr)
            {
                case 1:
                    result.Sqr();
                    break;
                case 2:
                    result.Cube();
                    break;
            }
            ReadKey();
        }
    }
}
