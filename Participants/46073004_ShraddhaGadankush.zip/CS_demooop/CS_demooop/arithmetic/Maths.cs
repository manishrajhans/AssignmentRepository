﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_demooop.arithmetic
{
  
        public class Maths
        {
            public int Add(int a, int b)
            {
                return a + b;
            }
            public double Add(double a, double b)
            {
                return a + b;
            }
            public DateTime Add(DateTime a, int b)
            {
                return a.AddDays(b);

            }

        }
    }


