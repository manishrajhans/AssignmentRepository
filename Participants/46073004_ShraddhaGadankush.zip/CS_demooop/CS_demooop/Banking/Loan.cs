﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_demooop.Banking;

namespace CS_demooop.Banking
{
    public class LoanAccount : Account 
    {
        public LoanAccount()
        {
            Balance += GetPremium();
            IssuePolicy();
        }

        public void Deposit(double amount)
        {
            if (Balance - amount > 0)
            {
                Balance -= amount;
            }
            else
            {
                throw new ApplicationException("Excess funds being deposited!");
            }
        }

        public double GetPremium()
        {
            return 1000.00d;
        }
        public void IssuePolicy()
        {
            Console.WriteLine("Policy issued!");
        }

        public void Withdraw(double amount)
        {
            Balance += amount;
        }
    }
} 