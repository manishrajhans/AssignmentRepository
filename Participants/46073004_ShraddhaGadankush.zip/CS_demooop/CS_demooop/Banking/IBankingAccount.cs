﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CS_demooop.Banking
{
    public interface IBankingAccount
    {
        void Deposit { double amount};

        void Withdraw { double amount };
    }
}
