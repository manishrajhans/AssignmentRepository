﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_demooop.Banking
{
    public class SavingsAccount : Account 
    {
        public delegate void LowBalanceHandler(double amount);
        public event LowBalanceHandler LowBalance;



        public void Deposit(double amount)
        {
            Balance += amount;   
        }

        public void Withdraw(double amount)
        {
            if (Balance-amount>1000)
            {
                Balance -= amount;
            }
            else
            {
                //throw new ApplicationException("Insufficient funds!");
                LowBalance?.Invoke(Balance);
            }

        }
    }
}
