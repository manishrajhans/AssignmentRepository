﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_demooop.Banking

{
    public abstract class Account
    {
        public double Balance { get; protected set; }

        //public abstract void Deposit(double amount);

        //public abstract void Withdraw(double amount);
    }
}
