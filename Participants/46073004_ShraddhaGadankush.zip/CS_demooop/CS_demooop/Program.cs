﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_demooop.demographics;
using CS_demooop.arithmetic;
using CS_demooop.Banking;

namespace CS_demooop
{
    class Program
    {
        static void Main(string[] args)
        {
            //Person p1 = new Person();
            //p1._id = 101;
            //p1._name = "james";
            //p1._age = 45.5f;

            //Person p2 = new Person(102, "john", 43.6f);

            //Console.WriteLine($"id : {p1._id},name : {p1._name},age :{p1._age}");
            //Console.WriteLine($"id : {p2._id},name : {p2._name},age :{p2._age}");
            //Console.WriteLine(p1.GetData());
            //Console.WriteLine(p2);
            //Maths m = new Maths();
            //Console.WriteLine(m.Add(20, 10));
            //Console.WriteLine(m.Add(20.23456d, 10.987456d));
            //Console.WriteLine(m.Add(DateTime.Now, 10));


            //Account acc = new Account();
            //savingsaccount acc = new savingsaccount();
            //LoanAccount acc = new LoanAccount();
            // try
            // {
            // Console.WriteLine(acc.Balance);
            //acc.Deposit(10000);
            // Console.WriteLine(acc.Balance);
            // acc.Withdraw(5500);
            //Console.WriteLine(acc.Balance);
            //acc.Withdraw(4000);
            // Console.WriteLine(acc.Balance);

            //Console.WriteLine(acc.Balance);
            //acc.Withdraw(10000);
            // Console.WriteLine(acc.Balance);
            // acc.Deposit(5500);
            // Console.WriteLine(acc.Balance);
            // acc.Deposit(4000);
            // Console.WriteLine(acc.Balance);


            // }
            // catch (ApplicationException ex)
            //  {

            //      Console.WriteLine(ex.Message);
            //  }

            //events
            SavingsAccount acc = new SavingsAccount();
            acc.LowBalance += Acc_LowBalance;
            Console.WriteLine(acc.Balance);
            acc.Deposit(10000);
            Console.WriteLine(acc.Balance);
            acc.Withdraw(5500);
            Console.WriteLine(acc.Balance);
            acc.Withdraw(4500);
            Console.WriteLine(acc.Balance);

            Console.ReadKey();
        }

        private static void Acc_LowBalance(double amount)
        {
            Console.WriteLine($"You have {amount} left in your account! , Hence current transaction is not possible!");

        }
    }
}




