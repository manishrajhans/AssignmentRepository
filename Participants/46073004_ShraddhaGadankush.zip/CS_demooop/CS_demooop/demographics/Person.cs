﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_demooop.demographics
{
    public class Person
    {
        private int _id;//Field(Data member)

        public int Id //Property - Used for encapsulating data members(Fields)
        {
            get
            {
                return _id;
            }
            set
            {
                if (value > 0)
                {
                    _id = value;
                }
                else
                {
                    throw new ApplicationException($"{value} is invalid for Id. It should be a value greater than zero!");
                }
            }
        }

        private string _name;

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _name = value;
                }
                else
                {
                    throw new ApplicationException("Name can't be empty!");
                }
            }
        }

        private float _age;

        public float Age
        {
            get
            {
                return _age;
            }
            set
            {
                if (value > 0)
                {
                    _age = value;
                }
                else
                {
                    throw new ApplicationException("Age must be more than 0!");
                }
            }
        }

        public Person()
        {
            _id = 0;
            _name = string.Empty;// ""
            _age = 0.0f;
        }

        public Person(int id, string name, float age)
        {
            Id = id;
            Name = name;
            Age = age;
        }

        public virtual string GetData()
        {
            return $"Id ;{Id},Name : {Name},Age:{Age}";
        }
        public override string ToString()
        {
            return $"Id : {Id},Name : {Name}, Age : {Age}"; 
        }
    }
}
