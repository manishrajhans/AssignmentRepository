﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_demooop.demographics
{
    public class Employee : Person
    {
        public int DeptNo { get; set; }

        public double salary { get; set; }

        public Employee() : base()//constructor chaining
        {
            DeptNo = 0;
            salary = 0.0d;
        }

        public Employee(int id, string name, float age, int deptno, double salary) : base(id, name, age)//constructor chaining
        {
            DeptNo = DeptNo;
            salary = salary;
        }

        public new string GetData()
        {
            return $"{base.GetData()}, DeptNo : {DeptNo},Salary :{salary}";
        }
        public new string ToString()
        {
            return $"{base.ToString()}, DeptNo : {DeptNo},Salary :{salary}";
            
        }

    }
}
