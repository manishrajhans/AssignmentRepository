﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CS_DemoJsonSerialization
{
{
    class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
    class Program
    {
        static void JsonSerialize()
        {
            Person p = new Person()
            {
                Id = 101,
                Name = "Rajat",

                DateOfBirth = DateTime.Parse("20-june-1999")


            };
            string personData= JsonConvert.SerializeObject(p);
            Console.WriteLine($"json serialized Person:{personData}");
        }

        static void JsonDeserialize()
        {
            Person p = JsonConvert.DeserializeObject<Person>("{ 'Id':101,'Name':'Rajat','DateOfBirth':'1999-06-20T00:00:00'}");
            Console.WriteLine($"Id:{p.Id},Name:{p.Name},DateOfBirth :{p.DateOfBirth}"); ;
        }
        static void Main(string[] args)
        {
            JsonSerialize();
            Console.WriteLine("\n\nSerilization completed..");
            JsonDeserialize();

            Console.ReadKey();
        }
    }
}
