﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoCollections.Collections
{
    //public class CGList
    //{
    //    private object[] store;
    //    private int count;

    //    public CGList(int initialCapacity)
    //    {
    //        store = new object[initialCapacity];
    //        count = 0;
    //    }

    //    public int Count
    //    {
    //        get
    //        {
    //            return count;
    //        }
    //    }

    //    public int Capacity
    //    {
    //        get
    //        {
    //            return store.Length;
    //        }
    //    }

    //    public void Add(object element)
    //    {
    //        if (Count == Capacity)
    //        {
    //            Array.Resize<object>(ref store, Count * 2);
    //        }
    //        store[count++] = element;
    //    }

    //    //Indexer
    //    public object this[int index]
    //    {
    //        get 
    //        { 
    //            if(index>=0 && index < Count)
    //            {
    //                return store[index];
    //            }
    //            else
    //            {
    //                throw new IndexOutOfRangeException($"Element at {index} doesn't exist!");
    //            }
    //        }
    //        //set 
    //        //{ 
    //        //    if(index>=0 && index < Count)
    //        //    {
    //        //        store[index] = value;
    //            //}
    //            //else
    //            //{
    //            //    throw new IndexOutOfRangeException($"Element at {index} is not possible!");
    //           // }
    //        //}
    //    }

    //    public IEnumerator GetEnumerator()
    //    {
    //        foreach(object element in store)
    //        {
    //            yield return element;
    //        }
    //    }
    //}



    public class CGList<TElement>
    {
        private TElement[] store;
        private int count;

        public CGList(int initialCapacity)
        {
            store = new TElement[initialCapacity];
            count = 0;
        }

        public int Count
        {
            get
            {
                return count;
            }
        }

        public int Capacity
        {
            get
            {
                return store.Length;
            }
        }

        public void Add(TElement element)
        {
            if (Count == Capacity)
            {
                Array.Resize<TElement>(ref store, Count * 2);
            }
            store[count++] = element;
        }

        //Indexer
        public TElement this[int index]
        {
            get
            {
                if (index >= 0 && index < Count)
                {
                    return store[index];
                }
                else
                {
                    throw new IndexOutOfRangeException($"Element at {index} doesn't exist!");
                }
            }
            //set 
            //{ 
            //    if(index>=0 && index < Count)
            //    {
            //        store[index] = value;
            //}
            //else
            //{
            //    throw new IndexOutOfRangeException($"Element at {index} is not possible!");
            // }
            //}
        }

        public IEnumerator<TElement> GetEnumerator()
        {
            foreach (TElement element in store)
            {
                yield return element;
            }
        }
    }
}
