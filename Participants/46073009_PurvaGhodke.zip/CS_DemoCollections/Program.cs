﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_DemoCollections.Collections;

namespace CS_DemoCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            CGList<int> list = new CGList<int>(3);
            Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");

            list.Add(1);
            Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            list.Add(2);
            Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            list.Add(3);
            Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            list.Add(4);
            Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");

            //for(int i = 0; i < list.Count; i++)
            //{
            //    Console.Write($"{list[i]}, ");
            //}

            foreach (var element in list){
                Console.Write($"{element}, ");
            }

            // ArrayList list = new ArrayList(3);
            //list.Add(1);
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add(2);
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add("Three");
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add(4.2345d);
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");

            ////for(int i = 0; i < list.Count; i++)
            //// {
            //   Console.Write($"{list[i]}, ");
            //}

            //foreach(object element in list)
            //{
            //if (element != null)
            //{
            //  Console.Write($"{element}, ");
            //}
            //}

            //Stack stk = new Stack(3);
            //stk.Push(1);
            //stk.Push(2);
            //stk.Push("Three");
            //stk.Push(4.2345d);
            //Console.WriteLine($"The count is:{stk.Count}");

            //while (stk.Count > 0)
            //{
            //  Console.Write($"{stk.Pop()}, ");
            //}

            //Queue q = new Queue(3);
            //q.Enqueue(1);
            //q.Enqueue(2);
            //q.Enqueue("Three");
            //q.Enqueue(4.2345d);

            //Console.WriteLine($"The count is:{q.Count}");

            //while (q.Count > 0)
            //{
            //    Console.Write($"{q.Dequeue()}, ");
            //}

            //Hashtable ht = new Hashtable(3);
            //ht.Add("One", 1);
            //ht.Add("Two", 2);
            //ht.Add("Three", 3);
            //ht.Add("Four", 4.2345);
            //Console.WriteLine($"The count is:{ht.Count}");

            //foreach(string key in ht.Keys)
            //{
            //  Console.Write($"{ht[key]}, ");

            //}



            //List<int> list = new List<int>(3);
            //list.Add(1);

            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add(2);
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add(3);
            //list.Add("Three");
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");
            //list.Add(4);
            //list.Add(4.2345d);
            //Console.WriteLine($"Collection - Capacity:{list.Capacity},Count:{list.Count}");

            //int sum = 0;
            //foreach(int element in list)
            //{
              //  Console.Write($"{element}, ");
                //sum += element;
            //}
            //Console.WriteLine($"\n\nThe sum is: {sum}");


            Console.ReadKey();
       
    }
   
    }
}
