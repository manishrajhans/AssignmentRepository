using System;

namespace Test{ //dll file 
	public class Arith{
		public static long Add(long i,long j){
			return(i+j);
		}
	}
}