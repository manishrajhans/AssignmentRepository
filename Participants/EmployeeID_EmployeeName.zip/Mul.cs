using System;

namespace Test{ //dll file 
	public class Arith1{
		public static long Mul(long i,long j){
			return(i*j);
		}
	}
}