﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace SelfPractice_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            //************************ARRAY LIST*************************
          //  ArrayList al = new ArrayList();

          // //Console.WriteLine( al.Capacity);
          //  al.Add(29);
          ////  Console.WriteLine(al.Capacity);
          //  al.Add("ananya");
          // // Console.WriteLine(al.Capacity);
          //  al.Add(34.90d);
          //  //Console.WriteLine(al.Capacity);
          //  al.Add('a');
          //  //Console.WriteLine(al.Capacity);
          //  al.Add('*');
          //  //Console.WriteLine(al.Capacity);


          //  foreach (Object obj in al)
          //  {
          //      Console.Write(obj+ " ");
          //  }

          //  al.Remove('a');
          //  Console.WriteLine();
          //  al.RemoveAt(2);
          //  al.RemoveAt(2);
          //  //Console.WriteLine(al.Capacity);
          //  al.RemoveAt(0);
          //  al.RemoveAt(0);
          //  Console.WriteLine(al.Capacity);

          //  foreach (Object obj in al)
          //  {
          //      Console.Write(obj +" ");
          //  }



            Console.ReadKey();
        }
    }
}
