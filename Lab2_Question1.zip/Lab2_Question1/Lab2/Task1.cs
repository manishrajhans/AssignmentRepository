﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab2_Question1

{
    class Task1
    {
    }
    struct operation
    {
        public int Number { get; set; }

        public int Display(int n)
        {
            
            int CubeRoot = n * n * n;
            return CubeRoot;
            
        }
        public int Display1(int n1)
        {
            
            int squareroot = n1 * n1;
            return squareroot;

        }
        
    }
}

        


