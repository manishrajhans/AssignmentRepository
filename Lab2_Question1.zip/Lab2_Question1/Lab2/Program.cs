﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab2_Question1;

namespace Lab2_Question1

{

    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter Number: ");
            int Number = Convert.ToInt32(Console.ReadLine());
            operation op = new operation();
            Console.WriteLine($"Cuberoot:{op.Display(Number)},SquareRoot:{op.Display1(Number)}");
            Console.ReadKey();
        }
    }
}

