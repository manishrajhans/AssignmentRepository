﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;

namespace Lab_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task 7
            ICICI icici1 = new ICICI();
            icici1.AccountType = (BankAccountTypeEnum)2;
            icici1.Deposit(50000);

            ICICI icici2 = new ICICI();
            icici2.AccountType = (BankAccountTypeEnum)1;

            icici2.Deposit(20000);
            Console.WriteLine("Account balance after respective deposits: ");

            Console.WriteLine($"Saving ICICI account balance is : {icici1.GetBalance()}");
            Console.WriteLine($"Current ICICI account balance is : {icici2.GetBalance()}");

            icici1.Transfer(icici2, 5000);
            Console.WriteLine("\nAccount balance after transfering 5000 from saving to current account : ");
            Console.WriteLine($"Saving ICICI account balance is : {icici1.GetBalance()}");
            Console.WriteLine($"Current ICICI account balance is : {icici2.GetBalance()}");

            HSBC hsbc1 = new HSBC();
            hsbc1.AccountType = (BankAccountTypeEnum)2;
            hsbc1.Deposit(50000);

            HSBC hsbc2 = new HSBC();
            hsbc2.AccountType = (BankAccountTypeEnum)1;
            hsbc2.Deposit(20000);

            Console.WriteLine("\nAccount balance after respective deposits: ");

            Console.WriteLine($"Saving HSBC account balance is : {hsbc1.GetBalance()}");
            Console.WriteLine($"Current HSBC account balance is : {hsbc2.GetBalance()}");

            hsbc1.Transfer(hsbc2, 30000);
            Console.WriteLine("\nAccount balance after transfering 30000 from saving to current account : ");
            Console.WriteLine($"Saving HSBC account balance is : {hsbc1.GetBalance()}");
            Console.WriteLine($"Current HSBC account balance is : {hsbc2.GetBalance()}");

            //Lab 5 Question 2
            icici1.CalculateInterest();
            Console.WriteLine($"\nInterest paid by ICICI bank on Saving Account: {icici1.GetInterest()}");

            hsbc1.CalculateInterest();
            Console.WriteLine($"\nInterest paid by ICICI bank on Saving Account: {hsbc1.GetInterest()}");

            Console.ReadKey();
        }
    }
}
