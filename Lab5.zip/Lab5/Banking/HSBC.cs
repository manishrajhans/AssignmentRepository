﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;

namespace Lab_5
{
    
        public class HSBC : BankAccount
        {
            //Task 6
            public override BankAccountTypeEnum AccountType
            {
                get; set;
            }

            public override bool Transfer(IBankAccount toAccount, double amount)
            {
                if (balance - amount >= 5000)
                {
                    balance = balance - amount;
                    toAccount.Deposit(amount);
                    return true;
                }
                else
                    return false;
            }

            public override bool Withdraw(double amount)
            {
                if (balance - amount >= 5000)
                {
                    balance = balance - amount;
                    return true;
                }
                else
                    return false;
            }

            //Lab 5 Question 2
            public override void CalculateInterest()
            {
                balance = balance * 5 / 100;
            }

            public double GetInterest()
            {
                return balance;
            }
        }
}

