﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
    
        //Task2
        //Enum type definition to specify possible set of values
        public enum BankAccountTypeEnum
        {
            Current = 1,
            Saving = 2
        }
    
}
