﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace La2_Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[5, 6];
            for(int i=0;i<5;i++)
            {
                for(int j=0;j<6;j++)
                {
                    Console.Write("Elements-[{0},{1}]:",i, j);
                    arr[i, j] = Convert.ToInt32(Console.ReadLine());

                }
            }
            Console.WriteLine("Data Entered By User is:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("\n");
                for (int j = 0; j < 6; j++)
                {
                    Console.Write("{0}\t", arr[i,j]);
                }
                Console.Write("\n\n");
            }
            Console.ReadKey();


        }
    }
}
